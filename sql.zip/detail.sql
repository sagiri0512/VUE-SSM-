/*
SQLyog Ultimate v13.1.1 (64 bit)
MySQL - 8.0.36 : Database - firstjob
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`firstjob` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `firstjob`;

/*Table structure for table `detail` */

DROP TABLE IF EXISTS `detail`;

CREATE TABLE `detail` (
  `DID` int NOT NULL AUTO_INCREMENT,
  `PID` int NOT NULL,
  `DImg` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`DID`),
  KEY `detail_product_PID` (`PID`),
  CONSTRAINT `detail_product_PID` FOREIGN KEY (`PID`) REFERENCES `product` (`PID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `detail` */

insert  into `detail`(`DID`,`PID`,`DImg`) values 
(1,1,'https://sagirinoinu.top/img/product/pear/pear1.png'),
(2,1,'https://sagirinoinu.top/img/product/pear/pear2.png'),
(3,1,'https://sagirinoinu.top/img/product/pear/pear3.png'),
(4,2,'https://sagirinoinu.top/img/product/coca-cola/coca-cola1.png'),
(5,2,'https://sagirinoinu.top/img/product/coca-cola/coca-cola2.png'),
(6,2,'https://sagirinoinu.top/img/product/coca-cola/coca-cola3.png'),
(7,3,'https://sagirinoinu.top/img/product/qiehuang/qiehuang1.png'),
(8,3,'https://sagirinoinu.top/img/product/qiehuang/qiehuang2.png'),
(9,3,'https://sagirinoinu.top/img/product/qiehuang/qiehuang3.png'),
(10,5,'https://sagirinoinu.top/img/product/apple/apple1.png'),
(11,5,'https://sagirinoinu.top/img/product/apple/apple2.png'),
(12,5,'https://sagirinoinu.top/img/product/apple/apple3.png'),
(13,4,'https://sagirinoinu.top/img/product/sprite/sprite1.png'),
(14,4,'https://sagirinoinu.top/img/product/sprite/sprite2.png'),
(15,4,'https://sagirinoinu.top/img/product/sprite/sprite3.png');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
